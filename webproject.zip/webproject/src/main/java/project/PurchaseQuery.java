package project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PurchaseQuery
 */
public class PurchaseQuery extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	int slno=0;
	String sname;
	String dte;
	String prdname;
	int qty = 0;
	int prc = 0;
	int amt = 0;
	String note;
	
    public PurchaseQuery() {
        super();
    }
    
    public PurchaseQuery(int slno, String sname, String dte, String prdname, int qty, int prc, int amt,String note) {
		super();
		this.slno=slno;
		this.sname = sname;
		this.dte = dte;
		this.prdname = prdname;
		this.qty = qty;
		this.prc = prc;
		this.amt = amt;
		this.note = note;
	}

//	@Override
//	public int hashCode() {
//		return Objects.hash(amt, dte, prc, prdname, qty, sname);
//	}

//	@Override
//	public boolean equals(Object obj) {
//		if (this == obj)
//			return true;
//		if (obj == null)
//			return false;
//		if (getClass() != obj.getClass())
//			return false;
//		PurchaseQuery other = (PurchaseQuery) obj;
//		return amt == other.amt && Objects.equals(dte, other.dte) && prc == other.prc
//				&& Objects.equals(prdname, other.prdname) && qty == other.qty && Objects.equals(sname, other.sname);
//	}

	@Override
//	public String toString() {
//		return "PurchaseQuery [sname=" + sname + ", dte=" + dte + ", prdname=" + prdname + ", qty=" + qty + ", prc="
//				+ prc + ", amt=" + amt + ", getInitParameterNames()=" + getInitParameterNames()
//				+ ", getServletConfig()=" + getServletConfig() + ", getServletContext()=" + getServletContext()
//				+ ", getServletInfo()=" + getServletInfo() + ", getServletName()=" + getServletName() + ", getClass()="
//				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Sellername = request.getParameter("sellername") ;
		String Date = request.getParameter("date") ;
		
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd_MMM_yyyy");
        String formattedDate = null;
        
        try {
            // Parse the input string into a Date object
            Date date = inputFormat.parse(Date);

            // Format the Date object into the output string format
            formattedDate = outputFormat.format(date);

            // Print the formatted date string
        } catch (ParseException e) {
            System.out.println("Error parsing date: " + e.getMessage());
        }
        
		String tablename= Sellername+"_"+formattedDate;
		
		try {	
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/billingsoftware","root","root");
			Statement st = con.createStatement();
		    st.execute("create database  IF NOT EXISTS billingsoftware");
			PreparedStatement ps  = con.prepareStatement( " SELECT"
					+ "       TABLE_NAME"
					+ "    FROM"
					+ "    information_schema.TABLES"
					+ "    WHERE"
					+ "        TABLE_TYPE LIKE 'BASE TABLE' AND "
					+ "        TABLE_NAME = ?");
			ps.setString(1,tablename);
		    ResultSet rs = ps.executeQuery();
		    String s = "";
		    
		    while(rs.next())
			{
				s =(rs.getString("TABLE_NAME"));
			}
		    
		    if(s.equalsIgnoreCase(tablename)) {
		    	String retrivequery = "select * from "+s;
		    	PreparedStatement ps1  = con.prepareStatement(retrivequery);
		    	ResultSet rs1 = ps1.executeQuery();
		    	
		    	List<PurchaseQuery> al = new ArrayList<PurchaseQuery>();
		    	while(rs1.next()) {
		    		slno = rs1.getInt(1);
		    		sname = rs1.getString(2);
		    		dte = rs1.getString(3);
		    		prdname = rs1.getString(4);
		    		qty = rs1.getInt(5);
		    		prc = rs1.getInt(6);
		    		amt = rs1.getInt(7);
		    		note = rs1.getString(8);
		    		
		    		al.add(new PurchaseQuery(slno,sname,dte,prdname,qty,prc,amt,note));
		    	}
		    	request.setAttribute("resultset", al);
		 	    RequestDispatcher rd = request.getRequestDispatcher("displaypurchases.jsp");
		 	    rd.forward(request, response);
		    }
		    else {
		    	request.setAttribute("error", "errors");
		    	RequestDispatcher rd = request.getRequestDispatcher("purchasequery.jsp");
		 	    rd.forward(request, response);
		    	System.out.println("No Such Table exists");
		    }
		    
		    con.close();
		    rs.close();
		    ps.close();
	}
		
		catch(Exception e)
		{
			 e.printStackTrace();
		}

}
	
	public String getNote() {
		return note;
	}
	
	public void setNote(String note) {
		this.note = note;
	}
	
	public int getSlno() {
		return slno;
	}
	
	public void setSlno(int slno) {
		this.slno = slno;
	}
	
	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getDte() {
		return dte;
	}

	public void setDte(String dte) {
		this.dte = dte;
	}

	public String getPrdname() {
		return prdname;
	}

	public void setPrdname(String prdname) {
		this.prdname = prdname;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public int getPrc() {
		return prc;
	}

	public void setPrc(int prc) {
		this.prc = prc;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}
	
//	   <%//@page import="java.sql.ResultSet"%>
//	   <% //ResultSet rs = (ResultSet)request.getAttribute("resultset");%>
//	   <%//while(rs.next()) { %>
//	   <!-- <tr class="table-info">
//	   <th scope="row">1</th>
//	      <td><%//=rs.getString(1)%></td>
//	      <td><%=//rs.getString(2)%></td>
//	      <td><%=//rs.getString(3)%></td>
//	      <td><%=//rs.getInt(4)%></td>
//	      <td><%=//rs.getInt(5)%></td>
//	      <td><%=//rs.getInt(6)%></td>
//	      <td></td>
//	      <td></td>
//	    </tr>
//	   <%//}%> -->
	
}
