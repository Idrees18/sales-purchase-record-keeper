package project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PurchaseDetails
 */
@SuppressWarnings("serial")
public class PurchaseDetails extends HttpServlet {
	int flag=0;
    public PurchaseDetails() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String Sellername = request.getParameter("sellername") ;
		String Date = request.getParameter("date") ;
		String Productname = request.getParameter("productname") ;
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		int price = Integer.parseInt(request.getParameter("price"));
		int Amount = quantity*price;
		String note = request.getParameter("note") ;
		
		SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd_MMM_yyyy");
        String formattedDate = null;
        
        try {
            // Parse the input string into a Date object
            Date date = inputFormat.parse(Date);

            // Format the Date object into the output string format
            formattedDate = outputFormat.format(date);

            // Print the formatted date string
        } catch (ParseException e) {
            System.out.println("Error parsing date: " + e.getMessage());
        }
        
		String tablename= Sellername+"_"+formattedDate;
	
		
		// store into database
		try {	
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/billingsoftware","root","root");
	    Statement st = con.createStatement();
	    st.execute("create database  IF NOT EXISTS billingsoftware");
	    //Statement st = con.createStatement();
	    st.execute("create table IF NOT EXISTS "+tablename+"(sl integer AUTO_INCREMENT ,sellername varchar(20),date varchar(20),productname varchar(20),quantity integer,price integer,amount integer,note varchar(20), PRIMARY KEY (sl))");
		String insertquery = "insert into "+tablename+"(sellername,date,productname,quantity,price,amount,note) values (?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(insertquery);
    	ps.setString(1,  Sellername);
		ps.setString(2, Date);
		ps.setString(3, Productname);
		ps.setInt(4,quantity);
		ps.setInt(5,price);
		ps.setInt(6, Amount);
		ps.setString(7,note);
	
		flag = ps.executeUpdate();
		System.out.println(flag);
		con.close();
		
		}
		
		catch(Exception e)
		{
			 e.printStackTrace();
		}
		if(flag >0) {
		request.setAttribute("Success","success");
 	    RequestDispatcher rd = request.getRequestDispatcher("purchasedetails.jsp");
 	    rd.forward(request, response);
		}
	}

}
